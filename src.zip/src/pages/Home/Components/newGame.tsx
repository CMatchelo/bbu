import { useMemo, useState } from "react";
import { RootState } from "../../../store";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { User } from "../../../types/User";
import { University } from "../../../types/University";
import { useUser } from "../../../Context/UserContext";
import { selectUniversitiesGrouped } from "../../../selectors/data.selectors";
import { generateLeagueSchedules } from "../../../utils/managerSchedule";
import { useTranslation } from "react-i18next";
import { generateAllPlayers } from "../../../utils/createPlayer";
import { setPlayers } from "../../../store/slices/dataSlice";
import { useAppDispatch } from "../../../hooks/useAppDispatch";

export default function NewGame() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { loadUser } = useUser();

  const universitiesById = useSelector(
    (state: RootState) => state.data.universitiesById,
  );

  const universities = useMemo(
    () => Object.values(universitiesById),
    [universitiesById],
  );

  const grouped = useSelector(selectUniversitiesGrouped);

  const [name, setName] = useState<string>("");
  const [selectedUniId, setSelectedUniId] = useState<string | null>(null);

  const selectedUni = useMemo(
    () => universitiesById[selectedUniId || ""],
    [selectedUniId, universitiesById],
  );

  const buildUniversitiesWithRoster = (
    players: ReturnType<typeof generateAllPlayers>,
  ) => {
    const playersByUni: Record<string, string[]> = {};

    for (const p of players) {
      if (!playersByUni[p.currentUniversity]) {
        playersByUni[p.currentUniversity] = [];
      }
      playersByUni[p.currentUniversity].push(p.id);
    }

    return universities.map((uni) => ({
      ...uni,
      roster: playersByUni[uni.id] || [],
    }));
  };

  const toRecord = <T extends { id: string }>(arr: T[]) =>
    Object.fromEntries(arr.map((i) => [i.id, i]));

  const createUser = (uni: University): User => ({
    id: crypto.randomUUID(),
    name,
    currentUniversity: uni,
    reputation: 50,
    currentSeason: 2026,
    isStartSeason: false,
  });

  const startGame = async () => {
    if (!selectedUni || !name.trim()) return;

    try {
      const user = createUser(selectedUni);
      const folderName = `${user.name}_${user.id}`;

      // schedule
      const schedule = generateLeagueSchedules(universities);
      const scheduleData = { matches: schedule, currentWeek: 1 };

      // players + roster
      const players = generateAllPlayers(universities);
      const universitiesWithRoster = buildUniversitiesWithRoster(players);

      // persist
      await window.api.saveGame(user);
      await window.api.saveSchedule(folderName, scheduleData);
      await window.api.savePlayers(folderName, toRecord(players));
      await window.api.saveUniversities(
        folderName,
        toRecord(universitiesWithRoster),
      );

      // redux
      dispatch(setPlayers(toRecord(players)));

      // context + navigation
      loadUser(user);
      navigate("/team");
    } catch (err) {
      console.error("Erro ao iniciar jogo:", err);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <input
        className="bg-white w-48 text-black"
        placeholder="Nome"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <span>Selecione uma universidade para treinar</span>

      <select
        className="bg-amber-950"
        value={selectedUniId ?? ""}
        onChange={(e) => setSelectedUniId(e.target.value)}
      >
        <option value="" disabled>
          -- selecionar --
        </option>

        {Object.entries(grouped).map(([leagueId, unis]) => (
          <optgroup key={leagueId} label={t(`championshipLocale.${leagueId}`)}>
            {unis.map((uni) => (
              <option key={uni.id} value={uni.id}>
                {uni.name} {uni.nickname}
              </option>
            ))}
          </optgroup>
        ))}
      </select>

      <button onClick={startGame} disabled={!name || !selectedUni}>
        Começar jogo
      </button>
    </div>
  );
}
