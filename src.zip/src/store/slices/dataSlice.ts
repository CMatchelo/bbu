import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Player } from "../../types/Player";
import { University } from "../../types/University";
import { Skill } from "../../types/Skill";

interface DataState {
  universitiesById: Record<string, University>;
  playersById: Record<string, Player>;
  loading: boolean;
}

const initialState: DataState = {
  universitiesById: {},
  playersById: {},
  loading: false,
};

export const loadUniversities = createAsyncThunk(
  "data/loadUniversities",
  async () => {
    const universities = await window.api.loadJson("universities");
    return universities;
  },
);

const dataSlice = createSlice({
  name: "data",
  initialState,
  reducers: {
    setPlayers(state, action: PayloadAction<Record<string, Player>>) {
      state.playersById = action.payload;
    },
    updatePlayer(
      state,
      action: PayloadAction<{ id: string; changes: Partial<Player> }>,
    ) {
      const player = state.playersById[action.payload.id];
      if (!player) return;
      Object.assign(player, action.payload.changes);
    },
    updatePlayerSkill(
      state,
      action: PayloadAction<{
        id: string;
        skill: keyof Skill;
        value: number;
      }>,
    ) {
      const player = state.playersById[action.payload.id];
      if (!player || !player.skills) return;
      player.skills[action.payload.skill] = action.payload.value;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loadUniversities.pending, (state) => {
        state.loading = true;
      })
      .addCase(loadUniversities.fulfilled, (state, action) => {
        state.loading = false;
        state.universitiesById = {};
        for (const uni of action.payload) {
          state.universitiesById[uni.id] = uni;
        }
      })
      .addCase(loadUniversities.rejected, (state) => {
        state.loading = false;
      });
  },
});

export const { setPlayers, updatePlayer, updatePlayerSkill } =
  dataSlice.actions;
export default dataSlice.reducer;
