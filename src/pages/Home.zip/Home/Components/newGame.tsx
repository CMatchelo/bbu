import { useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { User } from "../../../types/User";
import { University } from "../../../types/University";
import { useUser } from "../../../Context/UserContext";
import {
  selectUniversitiesGrouped,
  selectAllUniversities,
} from "../../../selectors/data.selectors";
import { generateLeagueSchedules } from "../../../utils/managerSchedule";
import { useTranslation } from "react-i18next";
import { generateAllPlayers } from "../../../utils/createPlayer";
import {
  setPlayers,
  setUniversities,
  loadUniversitiesFromFiles,
} from "../../../store/slices/dataSlice";
import { useAppDispatch } from "../../../hooks/useAppDispatch";
import { RootState } from "../../../store";
import { toRecord } from "../../../utils/toRecord";
import {
  setCurrentWeek,
  setSchedule,
} from "../../../store/slices/scheduleSlice";
import { createEmptyTeamSeasonStats } from "../../../utils/createEmptySeasonStats";
import { UniCard } from "./uniCard";

/* ── Difficulty config ─────────────────────────────────────────────────────── */
type Difficulty = "easy" | "medium" | "hard";

const DIFFICULTIES: {
  key: Difficulty;
  label: string;
  description: string;
  textColor: string;
  bgColor: string;
  borderColor: string;
  selectedBg: string;
}[] = [
  {
    key: "easy",
    label: "Fácil",
    description: "Adversários mais fracos e progressão mais rápida.",
    textColor: "text-emerald-400",
    bgColor: "bg-emerald-400/10",
    borderColor: "border-emerald-500/30",
    selectedBg: "bg-emerald-400/15",
  },
  {
    key: "medium",
    label: "Médio",
    description: "Experiência balanceada e desafios graduais.",
    textColor: "text-amber-400",
    bgColor: "bg-amber-400/10",
    borderColor: "border-amber-500/30",
    selectedBg: "bg-amber-400/15",
  },
  {
    key: "hard",
    label: "Difícil",
    description: "Rivais implacáveis. Cada decisão importa.",
    textColor: "text-rose-400",
    bgColor: "bg-rose-400/10",
    borderColor: "border-rose-500/30",
    selectedBg: "bg-rose-400/15",
  },
];

/* ── Component ─────────────────────────────────────────────────────────────── */
export default function NewGame() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { loadUser } = useUser();

  const grouped = useSelector(selectUniversitiesGrouped);
  const universities = useSelector(selectAllUniversities);
  const loading = useSelector((state: RootState) => state.data.loading);

  const [name, setName] = useState<string>("");
  const [selectedUniId, setSelectedUniId] = useState<string | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");

  useMemo(() => {
    if (universities.length === 0) dispatch(loadUniversitiesFromFiles());
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const selectedUni = useMemo(
    () => universities.find((u) => u.id === selectedUniId) ?? null,
    [selectedUniId, universities],
  );

  const buildUniversitiesWithRoster = (
    players: ReturnType<typeof generateAllPlayers>,
  ) => {
    const playersByUni: Record<string, string[]> = {};
    for (const p of players) {
      if (!playersByUni[p.currentUniversity])
        playersByUni[p.currentUniversity] = [];
      playersByUni[p.currentUniversity].push(p.id);
    }
    return universities.map((uni) => ({
      ...uni,
      stats: { [2026]: createEmptyTeamSeasonStats(2026) },
      roster: playersByUni[uni.id] || [],
    }));
  };

  const createUser = (uni: University): User => ({
    id: crypto.randomUUID(),
    name,
    currentUniversity: uni,
    reputation: 50,
    currentSeason: 2026,
    isStartSeason: false,
    difficulty, // pass difficulty into the user object
  });

  const startGame = async () => {
    if (!selectedUni || !name.trim()) return;
    try {
      const user = createUser(selectedUni);
      const folderName = `${user.name}_${user.id}`;
      const schedule = generateLeagueSchedules(universities);
      dispatch(setSchedule(schedule));
      dispatch(setCurrentWeek(1));

      const players = generateAllPlayers(universities);
      const universitiesWithRoster = buildUniversitiesWithRoster(players);
      dispatch(setPlayers(players));

      await window.api.saveGame(user);
      await window.api.saveSchedule(folderName, {
        matches: schedule,
        currentWeek: 1,
      });
      await window.api.savePlayers(folderName, toRecord(players));
      await window.api.saveUniversities(
        folderName,
        toRecord(universitiesWithRoster),
      );

      dispatch(setUniversities(universitiesWithRoster));
      dispatch(setPlayers(toRecord(players)));

      loadUser(user);
      navigate("/team");
    } catch (err) {
      console.error("Erro ao iniciar jogo:", err);
    }
  };

  const canStart = !!name.trim() && !!selectedUni && !loading;

  return (
    <div className="flex flex-row gap-6 mt-4 w-full items-start">
      <div className="flex flex-col gap-4 w-full max-w-md">
        <div
          className="bg-cardbgdark border border-mainbglight rounded-xl overflow-hidden
          hover:border-detail2 transition-colors duration-300 shadow-xl"
        >
          <div className="px-5 py-4 border-b border-mainbglight flex items-center gap-2">
            <span className="h-3 w-0.5 bg-detail1 rounded-full" />
            <span className="text-sm font-semibold uppercase tracking-widest text-detail1 opacity-80">
              Manager
            </span>
          </div>
          <div className="px-5 py-4">
            <input
              className="w-full bg-bg3 border border-mainbglight rounded-lg
                text-[13px] text-text1 font-medium
                px-3 py-2 placeholder-[#b0aac8]/40
                hover:border-detail1 focus:border-detail1 focus:outline-none
                transition-colors duration-150"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        </div>

        <div
          className="bg-cardbgdark border border-mainbglight rounded-xl overflow-hidden
          hover:border-detail2 transition-colors duration-300 shadow-xl"
        >
          <div className="px-5 py-4 border-b border-mainbglight flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="h-3 w-0.5 bg-detail1 rounded-full" />
              <span className="text-sm font-semibold uppercase tracking-widest text-detail1 opacity-80">
                University
              </span>
            </div>
            {loading && (
              <span className="text-xs text-[#b0aac8] animate-pulse">
                Loading…
              </span>
            )}
          </div>
          <div className="px-5 py-4">
            <UniSelect
              grouped={grouped}
              selectedUniId={selectedUniId}
              onSelect={setSelectedUniId}
              disabled={loading}
              t={t}
            />
          </div>
        </div>

        <div
          className="bg-cardbgdark border border-mainbglight rounded-xl overflow-hidden
          hover:border-detail2 transition-colors duration-300 shadow-xl"
        >
          <div className="px-5 py-4 border-b border-mainbglight flex items-center gap-2">
            <span className="h-3 w-0.5 bg-detail1 rounded-full" />
            <span className="text-sm font-semibold uppercase tracking-widest text-detail1 opacity-80">
              Dificuldade
            </span>
          </div>
          <div className="px-5 py-4 flex flex-col gap-2">
            {DIFFICULTIES.map((d) => {
              const isSelected = difficulty === d.key;
              return (
                <button
                  key={d.key}
                  type="button"
                  onClick={() => setDifficulty(d.key)}
                  className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg border
                    text-left transition-all duration-200 cursor-pointer
                    ${
                      isSelected
                        ? `${d.selectedBg} ${d.borderColor} shadow-sm`
                        : "bg-bg3 border-mainbglight hover:border-detail2"
                    }`}
                >
                  <div className="flex-1 flex flex-row gap-3 min-w-0">
                    <span
                      className={`text-sm font-semibold transition-colors duration-200 ${isSelected ? d.textColor : "text-text1"}`}
                    >
                      {d.label}
                    </span>
                    <p className="text-xs text-[#b0aac8] mt-0.5 leading-relaxed">
                      {d.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        <button
          onClick={startGame}
          disabled={!canStart}
          className="flex items-center justify-center gap-2
            bg-detail1 text-bg1 font-semibold text-sm
            px-5 py-2.5 rounded-xl
            hover:bg-detail2
            disabled:opacity-30 disabled:cursor-not-allowed
            transition-colors duration-200
            shadow-lg shadow-detail1/20"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
            className="size-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z"
            />
          </svg>
          Começar jogo
        </button>
      </div>

      {/* ── Right panel: UniCard ── */}
      <UniCard university={selectedUni} />
    </div>
  );
}

/* ── Custom university dropdown ────────────────────────────────────────────── */
interface UniSelectProps {
  grouped: Record<string, University[]>;
  selectedUniId: string | null;
  onSelect: (id: string) => void;
  disabled: boolean;
  t: (key: string) => string;
}

function UniSelect({
  grouped,
  selectedUniId,
  onSelect,
  disabled,
  t,
}: UniSelectProps) {
  const [open, setOpen] = useState(false);

  const allUnis = Object.values(grouped).flat();
  const selected = allUnis.find((u) => u.id === selectedUniId) ?? null;

  return (
    <div className="relative">
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between gap-2
          bg-bg3 border border-mainbglight rounded-lg
          px-3 py-2 text-[13px] font-medium
          hover:border-detail1 transition-colors duration-150
          disabled:opacity-40 disabled:cursor-not-allowed"
      >
        <span className={selected ? "text-text1" : "text-[#b0aac8]/40"}>
          {selected
            ? `${selected.name} — ${selected.nickname}`
            : "— selecionar —"}
        </span>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="#9b87f5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={`size-3.5 flex-shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        >
          <path d="m19.5 8.25-7.5 7.5-7.5-7.5" />
        </svg>
      </button>

      {open && (
        <div
          className="absolute z-50 mt-1 w-full
          bg-cardbgdark border border-mainbglight rounded-lg shadow-2xl shadow-black/40 overflow-hidden"
        >
          <ul
            className="max-h-64 overflow-y-auto py-1
            [&::-webkit-scrollbar]:w-1
            [&::-webkit-scrollbar-track]:bg-bg3
            [&::-webkit-scrollbar-thumb]:bg-mainbglight
            [&::-webkit-scrollbar-thumb]:rounded-full"
          >
            {Object.entries(grouped).map(([leagueId, unis]) => (
              <li key={leagueId}>
                <div className="flex items-center gap-2 px-3 pt-3 pb-1">
                  <span className="h-px flex-1 bg-mainbglight" />
                  <span className="text-[11px] font-bold uppercase tracking-widest text-detail1 opacity-60">
                    {t(`championshipLocale.${leagueId}`)}
                  </span>
                  <span className="h-px flex-1 bg-mainbglight" />
                </div>
                {unis.map((uni) => {
                  const isSelected = uni.id === selectedUniId;
                  return (
                    <button
                      key={uni.id}
                      type="button"
                      onClick={() => {
                        onSelect(uni.id);
                        setOpen(false);
                      }}
                      className={`w-full flex items-center justify-between gap-3
                        px-3 py-2 text-[13px] text-left
                        transition-colors duration-100 cursor-pointer
                        ${
                          isSelected
                            ? "bg-mainbglight text-detail1 font-semibold"
                            : "text-text1 hover:bg-bg3"
                        }`}
                    >
                      <span>{uni.name}</span>
                      <span className="text-xs text-[#b0aac8]">
                        {uni.nickname}
                      </span>
                    </button>
                  );
                })}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
