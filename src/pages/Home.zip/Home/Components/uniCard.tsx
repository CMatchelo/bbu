import { useTranslation } from "react-i18next";
import { University } from "../../../types/University";
import { LevelPips } from "../../../Components/levelPips";
import { Icons } from "../../../utils/icons";

interface UniCardProps {
  university: University | null;
}

interface DeptoCellProps {
  locale: string;
  level: number;
  icon: React.ReactNode;
}

const DeptoCell = ({ locale, level, icon }: DeptoCellProps) => {
  const { t } = useTranslation();
  return (
    <div className="flex items-center gap-3 py-2 border-b border-mainbglight last:border-0">
      {/* icon */}
      <span className="text-detail1 opacity-70 shrink-0">{icon}</span>

      {/* label */}
      <span className="text-[13px] text-[#b0aac8] flex-1">{t(locale)}</span>

      {/* pips */}
      <LevelPips level={level} />

      {/* level badge */}
      <span className="text-xs font-semibold text-detail1 bg-detail3 px-2 py-0.5 rounded-full w-16 text-center tabular-nums">
        {t("generalLocale.level")} {level}
      </span>
    </div>
  );
};

export const UniCard = ({ university }: UniCardProps) => {
  const { t } = useTranslation();

  if (!university)
    return (
      <div className="flex items-center justify-center h-40 text-sm text-[#b0aac8]">
        Select a university to play
      </div>
    );

  return (
    <div className="flex flex-col gap-3 mt-4 w-full max-w-md">
      <div
        className="bg-cardbgdark border border-mainbgdark rounded-xl overflow-hidden
        transition-colors duration-300 shadow-xl"
      >
        <div className="px-5 py-4 border-b border-cardbglight">
          <div>
            <h2 className="text-base font-bold tracking-tight">
              {university.name}
            </h2>
            <h3 className="text-sm text-[#b0aac8] mt-0.5">
              {university.nickname}
            </h3>
          </div>
          {/* <span className="flex items-center gap-1 bg-detail3 text-detail1 text-xs font-semibold px-2.5 py-1 rounded-full flex-shrink-0">
            <IconPrestige />
            {t("generalLocale.level")} {university.academicPrestige}
          </span> */}
        </div>

        <div className="px-5 py-3">
          <DeptoCell
            locale="universityStrings.court"
            level={university.courtLevel}
            icon={Icons.IconCourt}
          />
          <DeptoCell
            locale="universityStrings.gym"
            level={university.gymLevel}
            icon={Icons.IconGym}
          />
          <DeptoCell
            locale="universityStrings.medicalCenter"
            level={university.medicalCenterLevel}
            icon={Icons.IconMedical}
          />
          <DeptoCell
            locale="universityStrings.physioDept"
            level={university.physioLevel}
            icon={Icons.IconPhysio}
          />
          <DeptoCell
            locale="universityStrings.eduSupport"
            level={university.educationSupportLevel}
            icon={Icons.IconEdu}
          />
          <DeptoCell
            locale="universityStrings.prestige"
            level={university.academicPrestige}
            icon={Icons.IconPrestige}
          />
        </div>
        <div className="px-5 py-3 bg-bg3 border-t border-cardbglight">
          <p className="text-xs text-[#b0aac8] leading-relaxed italic">
            Aqui irá breve descrição da uni
          </p>
        </div>
      </div>
    </div>
  );
};
